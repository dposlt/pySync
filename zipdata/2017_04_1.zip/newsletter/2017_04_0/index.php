<?php
ob_start();
?><html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1250">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 15">
<meta name=Originator content="Microsoft Word 15">
<link rel=File-List href="images/filelist.xml">
<link rel=Edit-Time-Data href="images/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Kratochvil, Martin (MONETA)</o:Author>
  <o:LastAuthor>Kratochvil, Martin (MONETA)</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>10</o:TotalTime>
  <o:Created>2017-04-25T03:55:00Z</o:Created>
  <o:LastSaved>2017-04-25T03:55:00Z</o:LastSaved>
  <o:Pages>2</o:Pages>
  <o:Words>629</o:Words>
  <o:Characters>3715</o:Characters>
  <o:Lines>30</o:Lines>
  <o:Paragraphs>8</o:Paragraphs>
  <o:CharactersWithSpaces>4336</o:CharactersWithSpaces>
  <o:Version>16.00</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=themeData href="images/themedata.thmx">
<link rel=colorSchemeMapping href="images/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:HyphenationZone>21</w:HyphenationZone>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>CS</w:LidThemeOther>
  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
  DefSemiHidden="false" DefQFormat="false" DefPriority="99"
  LatentStyleCount="373">
  <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 9"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="header"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footer"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index heading"/>
  <w:LsdException Locked="false" Priority="35" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of figures"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope return"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="line number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="page number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of authorities"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="macro"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="toa heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 5"/>
  <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Closing"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Signature"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="true"
   UnhideWhenUsed="true" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Message Header"/>
  <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Salutation"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Date"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Note Heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Block Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Hyperlink"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="FollowedHyperlink"/>
  <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Document Map"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Plain Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="E-mail Signature"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Top of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Bottom of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal (Web)"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Acronym"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Cite"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Code"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Definition"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Keyboard"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Preformatted"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Sample"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Typewriter"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Variable"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Table"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation subject"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="No List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Contemporary"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Elegant"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Professional"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Balloon Text"/>
  <w:LsdException Locked="false" Priority="59" Name="Table Grid"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Theme"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" QFormat="true"
   Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" QFormat="true"
   Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" QFormat="true"
   Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" QFormat="true"
   Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" QFormat="true"
   Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" QFormat="true"
   Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" SemiHidden="true"
   UnhideWhenUsed="true" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
  <w:LsdException Locked="false" Priority="41" Name="Plain Table 1"/>
  <w:LsdException Locked="false" Priority="42" Name="Plain Table 2"/>
  <w:LsdException Locked="false" Priority="43" Name="Plain Table 3"/>
  <w:LsdException Locked="false" Priority="44" Name="Plain Table 4"/>
  <w:LsdException Locked="false" Priority="45" Name="Plain Table 5"/>
  <w:LsdException Locked="false" Priority="40" Name="Grid Table Light"/>
  <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Mention"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Smart Hyperlink"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:238;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:-536870145 1107305727 0 0 415 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:238;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536870145 1073786111 1 0 415 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-fareast-language:EN-US;}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
span.GramE
	{mso-style-name:"";
	mso-gram-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
.MsoPapDefault
	{mso-style-type:export-only;
	margin-bottom:10.0pt;
	line-height:115%;}
@page WordSection1
	{size:595.3pt 841.9pt;
	margin:70.85pt 70.85pt 70.85pt 70.85pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Norm�ln� tabulka";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin-top:0cm;
	mso-para-margin-right:0cm;
	mso-para-margin-bottom:10.0pt;
	mso-para-margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-fareast-language:EN-US;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=CS style='tab-interval:35.4pt'>
<img style="display: block" alt="" src="http://microsites.moneta.cz/migagent/res.php?img=2017_04_0__blank.gif%TRACKER%"   border="0" height="1" width="1">

<div class=WordSection1>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=600
 style='width:450.0pt;border-collapse:collapse;mso-yfti-tbllook:1184;
 mso-padding-alt:0cm 0cm 0cm 0cm'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td style='padding:0cm 0cm 0cm 0cm'>
  <p class=MsoNormal><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
  color:#270BB6;mso-fareast-language:CS'><o:p>&nbsp;</o:p></span></p>
  <div align=center>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=600
   style='width:450.0pt;border-collapse:collapse;mso-yfti-tbllook:1184;
   mso-padding-alt:0cm 0cm 0cm 0cm'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
    <td style='padding:0cm 0cm 0cm 0cm'>
    <p class=MsoNormal><a href="http://microsites.moneta.cz/migagent/url.php?url=aHR0cDovL3d3dy5tb25ldGEuY3ovbGlkZQ==%TRACKER%" target="_blank"><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#270BB6;
    mso-fareast-language:CS;mso-no-proof:yes;text-decoration:none;text-underline:
    none'><!--[if gte vml 1]><v:shapetype id="_x0000_t75" coordsize="21600,21600"
     o:spt="75" o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe" filled="f"
     stroked="f">
     <v:stroke joinstyle="miter"/>
     <v:formulas>
      <v:f eqn="if lineDrawn pixelLineWidth 0"/>
      <v:f eqn="sum @0 1 0"/>
      <v:f eqn="sum 0 0 @1"/>
      <v:f eqn="prod @2 1 2"/>
      <v:f eqn="prod @3 21600 pixelWidth"/>
      <v:f eqn="prod @3 21600 pixelHeight"/>
      <v:f eqn="sum @0 0 1"/>
      <v:f eqn="prod @6 1 2"/>
      <v:f eqn="prod @7 21600 pixelWidth"/>
      <v:f eqn="sum @8 21600 0"/>
      <v:f eqn="prod @7 21600 pixelHeight"/>
      <v:f eqn="sum @10 21600 0"/>
     </v:formulas>
     <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
     <o:lock v:ext="edit" aspectratio="t"/>
    </v:shapetype><v:shape id="_x0000_i1045" type="#_x0000_t75" style='width:450pt;
     height:49.5pt;visibility:visible'>
     <v:imagedata src="images/image001.jpg" o:href="cid:image001.jpg@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=600 height=66
    src="images/image001.jpg" v:shapes="_x0000_i1045"><![endif]></span></a><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><o:p></o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1'>
    <td style='padding:0cm 0cm 0cm 0cm'>
    <p class=MsoNormal><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:#282A2D;mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
     id="_x0000_i1044" type="#_x0000_t75" style='width:450pt;height:3.75pt;
     visibility:visible'>
     <v:imagedata src="images/image002.jpg" o:href="cid:image002.jpg@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=600 height=5
    src="images/image002.jpg" v:shapes="_x0000_i1044"><![endif]></span><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><o:p></o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:2'>
    <td style='background:white;padding:30.0pt 22.5pt 30.0pt 22.5pt'>
    <p class=MsoNormal style='margin-bottom:12.0pt'><b><span style='font-size:
    18.0pt;font-family:"Arial",sans-serif;color:#140757;mso-fareast-language:
    CS'>Duben 2017</span></b><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:#282A2D;mso-fareast-language:CS'><o:p></o:p></span></p>
    <p class=MsoNormal style='margin-bottom:12.0pt;text-align:justify'><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><br>
    </span><b><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:#140757;mso-fareast-language:CS'>Nov� produkt � �ivnostensk� hypot�ka</span></b><b><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><o:p></o:p></span></b></p>
    <p class=MsoNormal style='margin-bottom:12.0pt;text-align:justify'><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
    mso-fareast-language:CS'>Po del�� dob� p�ich�z�me s&nbsp;produktovou
    inovac� � �ivnostensk� hypot�ka. Zaji�t�n� ��elov� �v�r, kter�m je mo�n�
    financovat nemovitost ur�enou k&nbsp;bydlen� a podnik�n� �i �ist�
    podnik�n�.<o:p></o:p></span></p>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
     1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
      <td width=10 valign=top style='width:7.5pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='text-align:justify'><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1043"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1043"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
      <td style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'>��elem �v�ru je <b>koup�, rekonstrukce,
      refinancov�n� �i kombinace uveden�ch ��el� nemovitosti, kter� nen�
      v&nbsp;katastru nemovitosti vedena jako objekt ur�en� k&nbsp;bydlen�</b>
      (rodinn� d�m s&nbsp;kancel���/ordinac�, m�stsk� d�m s&nbsp;prodejnou a
      bytem/kancel���, ob�ansk� vybavenost reziden�n�ho charakteru).</span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'>
      <td width=10 valign=top style='width:7.5pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='text-align:justify'><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1042"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1042"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
      <td style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'>Plocha nemovitosti ur�en� k&nbsp;podnik�n� <b>m��e
      b�t vy��� ne� 50% (a� 100%)</b> u�itn� plochy nemovitosti. Vhodnost
      financov�n� nemovitosti je v�dy nutn� p�edem konzultovat s&nbsp;bankou.<o:p></o:p></span></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><b
      style='mso-bidi-font-weight:normal'><span style='mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1041"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1041"><![endif]></span></b><b><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>�rokov�
      sazba ji� od 2,99 %!</span></b><span style='font-size:11.5pt;font-family:
      "Arial",sans-serif;color:black;mso-fareast-language:CS'> (viz. <span
      class=GramE>p�ilo�en�</span> �rokov� l�stek)</span><b><span
      style='mso-fareast-language:CS'><o:p></o:p></span></b></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><b
      style='mso-bidi-font-weight:normal'><span style='mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="obr�zek_x0020_51"
       o:spid="_x0000_i1040" type="#_x0000_t75" style='width:3pt;height:5.25pt;
       visibility:visible;mso-wrap-style:square'>
       <v:imagedata src="images/image003.png" o:title=""/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="obr�zek_x0020_51"><![endif]></span></b><span
      style='mso-spacerun:yes'>�</span><span style='font-size:11.5pt;
      font-family:"Arial",sans-serif;color:black;mso-fareast-language:CS'>�v�r
      je mo�n� poskytnout <b>a� do v��e 80% LTV se splatnost� 30 let</b>,
      fixacemi na 1,3,5,10 let</span><span style='font-size:11.5pt;font-family:
      "Arial",sans-serif;color:#282A2D;mso-fareast-language:CS'>.</span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'> Po�adavky na bonitu klienta jsou toto�n� jako u
      standardn� hypot�ky. Budouc� p��jmy z&nbsp;pron�jmu nelze zapo��st do
      p��jmu klienta. �ivnostenskou hypot�ku nelze kombinovat s&nbsp;produktem
      Pru�n� hypot�ka.<o:p></o:p></span></p>
      </td>
     </tr>
    </table>
    </div>
    <p class=MsoNormal style='margin-bottom:12.0pt;text-align:justify'><b
    style='mso-bidi-font-weight:normal'><span style='mso-fareast-language:CS;
    mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1039" type="#_x0000_t75"
     style='width:3pt;height:5.25pt;visibility:visible'>
     <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
    src="images/image003.png" v:shapes="_x0000_i1039"><![endif]></span></b><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
    mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>Neakceptovateln�
    nemovitosti: hotely, penziony, bytov� domy s&nbsp;n�jemn�mi byty, ubytovny,
    v�robn� haly.<o:p></o:p></span></p>
    <p class=MsoNormal style='margin-bottom:12.0pt;text-align:justify'><b
    style='mso-bidi-font-weight:normal'><span style='mso-fareast-language:CS;
    mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="obr�zek_x0020_63" o:spid="_x0000_i1038"
     type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible;
     mso-wrap-style:square'>
     <v:imagedata src="images/image003.png" o:title=""/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
    src="images/image003.png" v:shapes="obr�zek_x0020_63"><![endif]></span></b><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
    mso-fareast-language:CS'><span style='mso-spacerun:yes'>� </span>�ivnostenskou
    hypot�ku prozat�m nen� mo�n� spo��tat v&nbsp;Hypote�n�m port�lu, p�ikl�d�me
    proto <span class=SpellE>excelovsk�</span> kalkul�tor. V&nbsp;port�le
    zalo�te �v�r jako standardn� hypot�ku a ve formul��i ��dosti o �v�r
    za�krtnete produkt �ivnostensk� hypot�ka. N� bank�� se ji� postar� o
    spr�vn� nastaven� produktu.</span><span style='font-size:11.5pt;font-family:
    "Arial",sans-serif;color:#282A2D;mso-fareast-language:CS'><br
    style='mso-special-character:line-break'>
    <![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
    <![endif]></span><b><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:#140757;mso-fareast-language:CS'><o:p></o:p></span></b></p>
    <p class=MsoNormal style='margin-bottom:12.0pt;text-align:justify'><b><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#140757;
    mso-fareast-language:CS'>Zru�en� pravidla pro zapo�ten� maxim�ln� v��e
    p��jmu z pron�jmu</span></b><span style='mso-fareast-language:CS'><o:p></o:p></span></p>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
     1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
      <td width=17 valign=top style='width:12.95pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='text-align:justify'><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1037"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1037"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
      <td width=523 style='width:392.05pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'>S okam�itou platnost� ru��me metodick� omezen�
      zapo�ten� maxim�ln� v��e p��jmu z&nbsp;pron�jmu do �rovn� 25%
      zapo�itateln�ch p��jm�. <b>Nyn� je tedy mo�n� zapo��st p��jmy
      z&nbsp;pron�jmu v&nbsp;pln� v��i</b>. (dle skute�nosti z&nbsp;da�ov�ho
      p�izn�n� nebo 60% z&nbsp;pron�jm�, kter� je�t� nepro�ly zdan�n�m. Budouc�
      p��jmy z&nbsp;pron�jmu d�le neakceptujeme.</span><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS'><o:p></o:p></span></p>
      </td>
     </tr>
    </table>
    </div>
    <p class=MsoNormal style='margin-bottom:12.0pt;text-align:justify'><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><o:p>&nbsp;</o:p></span></p>
    <p class=MsoNormal style='text-align:justify'><b><span style='font-size:
    11.5pt;font-family:"Arial",sans-serif;color:#140757;mso-fareast-language:
    CS'>Zkr�cen� garance platnosti �rokov� sazby<o:p></o:p></span></b></p>
    <p class=MsoNormal style='text-align:justify'><span style='font-size:11.5pt;
    font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:CS'><o:p>&nbsp;</o:p></span></p>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
     1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
      <td width=10 valign=top style='width:7.5pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='text-align:justify'><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1036"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1036"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
      <td style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'>Od <span class=GramE>23.4.2017</span> doch�z� ke
      zkr�cen� garance �rokov� sazby ze 45 na 30 dn� od data pod�n� ��dosti o
      �v�r. V&nbsp;t�to lh�t� mus� b�t dod�ny kompletn� podklady a p�ed�ny na
      schvalov�n�. Sou�asn� byla i zkr�cena lh�ta na podpis �v�rov� smlouvy
      z&nbsp;60 na 30 dn� od data schv�len�.</span><span style='font-size:11.5pt;
      font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
     </tr>
    </table>
    </div>
    <p class=MsoNormal style='margin-top:9.0pt;margin-right:0cm;margin-bottom:
    9.0pt;margin-left:0cm;text-align:justify;line-height:18.0pt'><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'>V p��loze tohoto e-mailu najdete n�sleduj�c�
    dokumenty ke sta�en�:<o:p></o:p></span></p>
    <div align=center>
    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
     width="100%" style='width:100.0%;border-collapse:collapse;mso-yfti-tbllook:
     1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
     <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
      <td width=10 valign=top style='width:7.5pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='text-align:justify'><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1035"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1035"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
      <td style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'>Prezentace </span><span style='font-size:11.5pt;
      font-family:"Arial",sans-serif;color:black;mso-fareast-language:CS'>�ivnostensk�
      hypot�ka</span><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
      color:#282A2D;mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
     </tr>
     <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'>
      <td width=10 valign=top style='width:7.5pt;padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='text-align:justify'><span style='font-size:
      11.5pt;font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:
      CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape id="_x0000_i1034"
       type="#_x0000_t75" style='width:3pt;height:5.25pt;visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1034"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
      <td style='padding:0cm 0cm 0cm 0cm'>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:black;
      mso-fareast-language:CS'>Produktov� list a metodika �ivnostensk� hypot�ky</span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><o:p></o:p></span></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
       id="_x0000_i1033" type="#_x0000_t75" style='width:3pt;height:5.25pt;
       visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1033"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>Kalkul�tor
      </span><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
      color:black;mso-fareast-language:CS'>�ivnostensk� hypot�ky a Pru�n�
      hypot�ky<o:p></o:p></span></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
       id="_x0000_i1032" type="#_x0000_t75" style='width:3pt;height:5.25pt;
       visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1032"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>Aktualizovan�
      <span class=GramE>��dost o H�</span><o:p></o:p></span></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
       id="_x0000_i1031" type="#_x0000_t75" style='width:3pt;height:5.25pt;
       visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1031"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>Aktualizovan�
      prezentace H�<o:p></o:p></span></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
       id="_x0000_i1030" type="#_x0000_t75" style='width:3pt;height:5.25pt;
       visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1030"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>P�ehled
      �rokov�ch sazeb platn� k&nbsp;<span class=GramE>2<span style='color:black'>8</span>.<span
      style='color:black'>3</span>.2017</span><o:p></o:p></span></p>
      <p class=MsoNormal style='margin-bottom:9.0pt;text-align:justify'><span
      style='mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
       id="_x0000_i1029" type="#_x0000_t75" style='width:3pt;height:5.25pt;
       visibility:visible'>
       <v:imagedata src="images/image003.png" o:href="cid:image003.png@01D2BCEA.29F2C1B0"/>
      </v:shape><![endif]--><![if !vml]><img border=0 width=4 height=7
      src="images/image003.png" v:shapes="_x0000_i1029"><![endif]></span><span
      style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
      mso-fareast-language:CS'><span style='mso-spacerun:yes'>�</span>Aktualizovan�
      kontakty</span><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
      color:black;mso-fareast-language:CS'><o:p></o:p></span></p>
      </td>
     </tr>
    </table>
    </div>
    <p class=MsoNormal style='margin-top:9.0pt;margin-right:0cm;margin-bottom:
    9.0pt;margin-left:0cm;line-height:18.0pt'><span style='font-size:11.5pt;
    font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:CS'>Jan Brejl
    <br>
    Mana�er </span><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:black;mso-fareast-language:CS'>extern� distribuce</span><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><o:p></o:p></span></p>
    <p class=MsoNormal style='margin-top:9.0pt;margin-right:0cm;margin-bottom:
    9.0pt;margin-left:0cm;text-align:justify'><span style='font-size:11.5pt;
    font-family:"Arial",sans-serif;color:#282A2D;mso-fareast-language:CS'>MONETA
    Money Bank, a. s.<o:p></o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes'>
    <td style='padding:0cm 0cm 0cm 0cm'>
    <p class=MsoNormal><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:#282A2D;mso-fareast-language:CS;mso-no-proof:yes'><!--[if gte vml 1]><v:shape
     id="_x0000_i1028" type="#_x0000_t75" style='width:450pt;height:3.75pt;
     visibility:visible'>
     <v:imagedata src="images/image002.jpg" o:href="cid:image002.jpg@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=600 height=5
    src="images/image002.jpg" v:shapes="_x0000_i1028"><![endif]></span><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'><o:p></o:p></span></p>
    </td>
   </tr>
  </table>
  </div>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:12.0pt;font-family:"Times New Roman",serif;mso-fareast-language:
  CS'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'>
  <td style='padding:0cm 0cm 0cm 0cm'>
  <div align=center>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=600
   style='width:450.0pt;border-collapse:collapse;mso-yfti-tbllook:1184;
   mso-padding-alt:0cm 0cm 0cm 0cm'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
    <td style='padding:11.25pt 0cm 0cm 0cm'>
    <p class=MsoNormal><a href="https://www.facebook.com/monetamoneybank/"
    title="&quot;&quot; "><span style='font-size:11.5pt;font-family:"Arial",sans-serif;
    color:#270BB6;mso-fareast-language:CS;mso-no-proof:yes;text-decoration:
    none;text-underline:none'><!--[if gte vml 1]><v:shape id="_x0000_i1027"
     type="#_x0000_t75" style='width:18.75pt;height:18.75pt;visibility:visible'>
     <v:imagedata src="images/image004.jpg" o:href="cid:image004.jpg@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=25 height=25
    src="images/image004.jpg" v:shapes="_x0000_i1027"><![endif]></span></a><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'>&nbsp;&nbsp;</span><a
    href="https://twitter.com/MONETAMoneyBank" title="&quot;&quot; "><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#270BB6;
    mso-fareast-language:CS;mso-no-proof:yes;text-decoration:none;text-underline:
    none'><!--[if gte vml 1]><v:shape id="_x0000_i1026" type="#_x0000_t75"
     style='width:18.75pt;height:18.75pt;visibility:visible'>
     <v:imagedata src="images/image005.jpg" o:href="cid:image005.jpg@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=25 height=25
    src="images/image005.jpg" v:shapes="_x0000_i1026"><![endif]></span></a><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'>&nbsp;&nbsp;</span><a
    href="https://www.youtube.com/user/SNGEMB" title="&quot;&quot; "><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#270BB6;
    mso-fareast-language:CS;mso-no-proof:yes;text-decoration:none;text-underline:
    none'><!--[if gte vml 1]><v:shape id="_x0000_i1025" type="#_x0000_t75"
     style='width:18.75pt;height:18.75pt;visibility:visible'>
     <v:imagedata src="images/image006.jpg" o:href="cid:image006.jpg@01D2BCEA.29F2C1B0"/>
    </v:shape><![endif]--><![if !vml]><img border=0 width=25 height=25
    src="images/image006.jpg" v:shapes="_x0000_i1025"><![endif]></span></a><span
    style='font-size:11.5pt;font-family:"Arial",sans-serif;color:#282A2D;
    mso-fareast-language:CS'>&nbsp;&nbsp; <o:p></o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'>
    <td style='padding:11.25pt 0cm 11.25pt 0cm'>
    <p class=MsoNormal><span style='font-size:7.0pt;font-family:"Arial",sans-serif;
    color:#282A2D;mso-fareast-language:CS'>Toto je obchodn� sd�len� spole�nosti
    <b>MONETA Money Bank, a. s.</b> Vysko�ilova 1422/1a, 140 28 Praha 4 -
    Michle | I�O 25672720 | Zaps�no u MS v Praze, odd. B, <span class=SpellE>vl</span>.
    5403</span><span style='font-size:8.0pt;font-family:"Arial",sans-serif;
    color:#282A2D;mso-fareast-language:CS'><o:p></o:p></span></p>
    </td>
   </tr>
  </table>
  </div>
  </td>
 </tr>
</table>

</div>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</body>

</html>
<?php
$contents = ob_get_contents();
ob_end_clean();

$mid = isset($_GET["MID"]) && is_numeric($_GET["MID"]) ? "&MID={$_GET["MID"]}" : "";
$cid = isset($_GET["CID"]) && is_numeric($_GET["CID"]) ? "&CID={$_GET["CID"]}" : "";

echo str_replace("%TRACKER%", $mid.$cid, $contents);